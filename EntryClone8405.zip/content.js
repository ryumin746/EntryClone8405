
(() => {
  'use strict';
  const LIMIT = 8405;

  function apply() {
    try {
      if (window.Entry) window.Entry.maxCloneLimit = LIMIT;
    } catch (_) {}
  }

  apply();
  const timer = setInterval(apply, 50);
  window.addEventListener('beforeunload', () => clearInterval(timer), {once: true});
})();
