(() => {
  'use strict';

  // 43 × 43 × 5 = 9,245
  const LIMIT = 9245;
  const INTERVAL = 25;

  let lastEntry = null;

  function patchEntry(entry) {
    if (!entry || typeof entry !== 'object') return;

    try {
      // Entry.maxCloneLimit is what the clone creation code checks.
      entry.maxCloneLimit = LIMIT;
      lastEntry = entry;
    } catch (_) {}
  }

  function apply() {
    try {
      patchEntry(window.Entry);

      // Some Entry runtime transitions replace/recreate the Entry object.
      // Re-apply whenever that happens.
      if (window.Entry && window.Entry.maxCloneLimit !== LIMIT) {
        window.Entry.maxCloneLimit = LIMIT;
      }

      // If the runtime exposes Entry through the global object again after
      // play starts, catch that replacement as well.
      if (lastEntry && lastEntry !== window.Entry) {
        patchEntry(window.Entry);
      }
    } catch (_) {}
  }

  // First attempt as early as possible.
  apply();

  // Entry is often initialized/reinitialized after the page has loaded and
  // when the project switches into play mode, so keep the patch alive.
  const timer = setInterval(apply, INTERVAL);

  // Also react quickly to SPA-style DOM/runtime transitions.
  const observer = new MutationObserver(apply);
  try {
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  } catch (_) {}

  window.addEventListener('beforeunload', () => {
    clearInterval(timer);
    try { observer.disconnect(); } catch (_) {}
  }, { once: true });
})();
